# Revision status value set - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Revision status value set**

## ValueSet: Revision status value set 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/ValueSet/RevisionStatusVS | *Version*:0.1.0 |
| Active as of 2026-06-03 | *Computable Name*:RevisionStatusVS |

 **References** 

* [Epidemiologist](StructureDefinition-Epidemiologist.md)
* [Regional health authority](StructureDefinition-RegionalHealthAuthority.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "RevisionStatusVS",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-shareablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-publishablevalueset",
    "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-computablevalueset"]
  },
  "url" : "http://example.org/ValueSet/RevisionStatusVS",
  "version" : "0.1.0",
  "name" : "RevisionStatusVS",
  "title" : "Revision status value set",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-06-03T19:02:34+00:00",
  "publisher" : "DHIS2",
  "contact" : [{
    "name" : "DHIS2",
    "telecom" : [{
      "system" : "url",
      "value" : "http://dhis2.org"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "http://example.org/CodeSystem/RevisionStatusCS"
    }]
  }
}

```
